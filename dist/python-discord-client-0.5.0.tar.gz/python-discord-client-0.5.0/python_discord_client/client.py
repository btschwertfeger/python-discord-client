import requests

import exceptions
class Client(object):

    def __init__(self):
        raise NotImplementedError

    